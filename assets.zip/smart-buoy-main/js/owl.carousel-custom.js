$(function(){
	'use-strict';

	// carousel
	$("#carousel-features").owlCarousel({
      	slideSpeed : 300,
      	paginationSpeed : 400,
      	singleItem: true
  	});

  	// carousel
	$("#carousel-features2").owlCarousel({
      	slideSpeed : 300,
      	paginationSpeed : 400,
      	items: 2,
      	itemsMobile: 2
  	});

  	// carousel
	$("#client").owlCarousel({
      	slideSpeed : 300,
      	paginationSpeed : 400,
      	items: 2,
      	itemsMobile: 2
  	});

  	// carousel
	$("#client2").owlCarousel({
      	slideSpeed : 300,
      	paginationSpeed : 400,
      	items: 1,
      	singleItem: true
  	});


  	// carousel
	$("#carousel-slider").owlCarousel({
      	slideSpeed : 300,
      	paginationSpeed : 400,
      	singleItem: true
  	});

});