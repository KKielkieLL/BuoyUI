$(function(){
	'use-strict';

	// laoding
    $("#loading").fakeLoader({
      
      	bgColor: '#4568dc',
      	zIndex: 999,
     	spinner: 'spinner1',

    });


});