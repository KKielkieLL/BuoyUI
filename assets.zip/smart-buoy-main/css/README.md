# Project Name: [Smart-Buoy]

## Description
This repository contains various CSS files used for styling web pages in conjunction with the JavaScript files provided. These CSS files enhance the visual appeal and layout of web pages.

## Contents
- AjaxLoader.html
- animsition.css
- font-awesome.min.css
- grabbing.html
- lightbox.min.css
- loading.css
- materialize.min.css
- owl.carousel.css
- owl.theme.css
- owl.transitions.css
- slick-theme.css
- slick.css
- style.css

## Usage
These CSS files can be included in your HTML documents to style your web pages. Each CSS file serves a specific purpose and enhances the appearance of different elements on the page.

## Credits
- [Font Awesome](https://fontawesome.com/)
- [MaterializeCSS](https://materializecss.com/)
- [Owl Carousel](https://owlcarousel2.github.io/OwlCarousel2/)
- [Slick Carousel](https://kenwheeler.github.io/slick/)

## License
Unless otherwise specified in each file, all CSS files in this repository are provided under the [MIT License](https://opensource.org/licenses/MIT).
