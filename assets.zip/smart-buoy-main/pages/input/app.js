// app.js

const buoyForm = document.getElementById('buoyForm');
const buoyList = document.getElementById('buoyList');

// Save and update buoy data
if (buoyForm) {
    buoyForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const deploymentTime = document.getElementById('deploymentTime').value;
        const fishCatches = document.getElementById('fishCatches').value;
        const retrievalDate = document.getElementById('retrievalDate').value;
        const status = document.getElementById('status').value;
        const remarks = document.getElementById('remarks').value;
        const imageFile = document.getElementById('imageUpload').files[0];

        if (imageFile) {
            const reader = new FileReader();
            reader.readAsDataURL(imageFile);
            reader.onload = function() {
                const imageData = reader.result;
                addBuoy(deploymentTime, fishCatches, retrievalDate, status, remarks, imageData);
            };
        } else {
            addBuoy(deploymentTime, fishCatches, retrievalDate, status, remarks, null);
        }
    });
}

// Function to add buoy to localStorage
function addBuoy(deploymentTime, fishCatches, retrievalDate, status, remarks, imageData) {
    const buoy = {
        id: Date.now(),
        deploymentTime,
        fishCatches,
        retrievalDate,
        status,
        remarks,
        imageData
    };

    const buoys = JSON.parse(localStorage.getItem('buoys')) || [];
    buoys.push(buoy);
    localStorage.setItem('buoys', JSON.stringify(buoys));

    window.location.href = 'display.html';  // Redirect to display page after submission
}

// Function to display buoy data
if (buoyList) {
    displayBuoys();
}

function displayBuoys() {
    const buoys = JSON.parse(localStorage.getItem('buoys')) || [];
    buoyList.innerHTML = '';

    buoys.forEach((buoy) => {
        const buoyItem = document.createElement('div');
        buoyItem.classList.add('buoy-item');

        const buoyHTML = `
            <h4>Deployment Time: ${new Date(buoy.deploymentTime).toLocaleString()}</h4>
            <p><strong>Fish Catches (KG):</strong> ${buoy.fishCatches}</p>
            <p><strong>Retrieval Date:</strong> ${new Date(buoy.retrievalDate).toLocaleDateString()}</p>
            <p><strong>Status:</strong> ${buoy.status}</p>
            <p><strong>Remarks:</strong> ${buoy.remarks}</p>
        `;
        buoyItem.innerHTML = buoyHTML;

        if (buoy.imageData) {
            const buoyImage = document.createElement('img');
            buoyImage.src = buoy.imageData;
            buoyItem.appendChild(buoyImage);
        }

        const actions = document.createElement('div');
        actions.classList.add('actions');

        buoyItem.appendChild(actions);
        buoyList.appendChild(buoyItem);
    });
}

// Edit function
function editBuoy(id) {
    const buoys = JSON.parse(localStorage.getItem('buoys')) || [];
    const buoy = buoys.find(b => b.id === id);

    document.getElementById('deploymentTime').value = buoy.deploymentTime;
    document.getElementById('fishCatches').value = buoy.fishCatches;
    document.getElementById('retrievalDate').value = buoy.retrievalDate;
    document.getElementById('status').value = buoy.status;
    document.getElementById('remarks').value = buoy.remarks;

    deleteBuoy(id);  // Remove and re-add after editing
}

// Delete function
function deleteBuoy(id) {
    let buoys = JSON.parse(localStorage.getItem('buoys')) || [];
    buoys = buoys.filter(buoy => buoy.id !== id);
    localStorage.setItem('buoys', JSON.stringify(buoys));
    displayBuoys();
}
