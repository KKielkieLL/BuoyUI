# Project Name: [Smart-Buoy]

## Description
This repository contains several JavaScript files that enhance the functionality and appearance of web pages. These files are intended to be used as plugins or libraries in web development projects. Additionally, some of the files utilize a template for animations.

## Contents
- animsition.js
- custom-portfolio.js
- custom.js
- fakeloader.min.js
- jquery.filterizr.custom.html
- jquery.filterizr.min.js
- jquery.min.js
- lightbox.min.js
- loading.js
- materialize.min.js
- owl.carousel-custom.js
- owl.carousel.min.js
- slick.min.js

## Installation
To use any of these JavaScript files in your project, you can download them directly from this repository or include them via a content delivery network (CDN). Ensure to include the necessary dependencies if required by each file.

## Usage
Each JavaScript file in this repository serves a specific purpose. Refer to the documentation or comments within each file to understand its functionality and how to use it effectively in your project. For animations, the animsition.js file utilizes a template for animations.

## Credits
- [Animsition.js](https://github.com/blivesta/animsition)
- [jQuery](https://jquery.com/)
- [Filterizr.js](https://yiotis.net/filterizr/)
- [Lightbox.js](https://lokeshdhakar.com/projects/lightbox2/)
- [MaterializeCSS](https://materializecss.com/)
- [Owl Carousel](https://owlcarousel2.github.io/OwlCarousel2/)
- [Slick Carousel](https://kenwheeler.github.io/slick/)

## License
Unless otherwise specified in each file, all JavaScript files in this repository are provided under the [MIT License](https://opensource.org/licenses/MIT).
